package javaapplication3;

public class Operaciones{
    public static void main(String[] args) {
           Interfaz i = new Interfaz();// manda a llamar la interfaz
i.setVisible(true); 
    }
    // Método para calcular la fórmula general
    public  double[]formula(int A, int B, int C) {
       
        // Calcular el discriminante
        double discriminante = Math.pow(B, 2) - 4 * A * C;
        // Math oww realiza la uncion de elevar un numero a su exponente. base,exponente
/*El valor del discriminante 
𝐷
D permite determinar la naturaleza de las soluciones (raíces) de la ecuación cuadrática. */
        // Si el discriminante es negativo, no hay soluciones reales
        if (discriminante < 0) {
            return null; // Devolver null si no hay soluciones reales
        }

        // Si el discriminante es no negativo, calcular las dos soluciones
        double x1 = (-B + Math.sqrt(discriminante)) / (2 * A);
        double x2 = (-B - Math.sqrt(discriminante)) / (2 * A);

        // Retornar un arreglo con ambas soluciones
        return new double[]{x1, x2};
         
    }
}

