package pilaunion;

import java.util.InputMismatchException;
import java.util.Scanner;

import java.util.InputMismatchException;
import java.util.Scanner;

public class PilaUnion {

    public static Scanner teclado = new Scanner(System.in);
    public static String[] pilaA;
    public static int tope1 = 0;
    public static String[] pilaB;
    public static int tope2 = 0;
    public static String[] pilaUnida;

    public static void main(String[] args) {

        System.out.println("Ingresa el tamaño de la pila");
        int tamaño = teclado.nextInt();
        pilaA = new String[tamaño];
        pilaB = new String[tamaño];
        int opcion;

        do {
            System.out.println("Menu");
            System.out.println("1. Llenar la pila A");
            System.out.println("2. Llenar la pila B");
            System.out.println("3. Unir las pilas");
            System.out.println("4. Mostrar");
            System.out.println("5.Salir");
            System.out.println("Ingrese la opcion: ");

            try {
                opcion = teclado.nextInt();

                switch (opcion) {
                    case 1 ->
                        llenarPilaA();
                    case 2 ->
                        llenarPilaB();
                    case 3 ->
                        Union();
                    case 4 ->
                        Mostrar();
                    case 5 ->
                        System.out.println("Salio. Gracias");
                    default ->
                        System.out.println("No valido");
                }

            } catch (InputMismatchException e) {
                System.out.println("Error ingresa un numero entero...");
                teclado.next();
                opcion = 0;
            }
        } while (opcion != 5);
    }

    private static void llenarPilaA() {
        if (tope1 < pilaA.length) {
            for (int i = tope1; i < pilaA.length; i++) {
                int numero = (int) (Math.random() * 28 + 1);  // Generar un múltiplo de 7 positivo
                int numeroSiete = numero * 7;
                String letraA = Integer.toString(numeroSiete);
                // Convertir int a String
                pilaA[tope1] = letraA;
                tope1++;
            }
            System.out.println("Se lleno la pila");
        } else {
            System.out.println("Pila llena");
        }
    }

    private static void llenarPilaB() {
        if (tope2 < pilaB.length) {
            for (int i = tope2; i < pilaB.length; i++) {
                char letra = (char) (Math.random() * 26 + 'A');
                for (i = 0; i < tope2; i++) {//Recorre los elementos de la pila
                    if (pilaB[i].equals(String.valueOf(letra))) {//evalua si se encuntra esa letra ya en la pila
                        break; // si lo encuentra se genera un bucle 
                    }
                }
                // Si no se encontró la letra en la pila, entonces i (letra nueva) llegó hasta tope
                if (i == tope2) {
                    pilaB[tope2] = String.valueOf(letra);
                    tope2++;
                }
            }
            System.out.println("Se lleno la pila");
        } else {
            System.out.println("Pila llena");

        }
    }

    private static String[] Union() {
        // Determinar el tamaño de la pila unida como el ultimo de los dos topes
        int tamañoUnido = Math.min(tope1, tope2);
        pilaUnida = new String[tamañoUnido];

        for (int i = 0; i < tamañoUnido; i++) {
            //concatenan los elementos de la pila A y la pila B en cada posición correspondiente:
            pilaUnida[i] = pilaA[i] + pilaB[i];
        }
        return pilaUnida;
    }

    private static void Mostrar() {
        String opcion2;
        do {
            System.out.println("a. Mostrar la pila A");
            System.out.println("b. Mostrar la pila B");
            System.out.println("c. Mostrar la pila Unida");
            System.out.println("d. Salir");

            try {
                opcion2 = teclado.next();

                switch (opcion2) {
                    case "a":
                        if (tope1 > 0) {
                            System.out.println("Los elementos de la pila son: ");
                            for (int i = 0; i < tope1; i++) {
                                System.out.println(pilaA[i]);
                            }

                        } else {
                            System.out.println("La pila se encuentra vacia ");
                        }
                        break;

                    case "b":
                        if (tope2 > 0) {
                            System.out.println("Los elementos de la pila son: ");
                            for (int i = 0; i < tope2; i++) {
                                System.out.println(pilaB[i]);
                            }
                        } else {
                            System.out.println("La pila se encuentra vacia");
                        }
                        break;
                    case "c":
                        if (pilaUnida != null && pilaUnida.length > 0) {
                            // el valor null veridica si se encuentra la variable y poli.length el tama de la pila, todo esto ayor a cero
                            System.out.println("Pila unida: ");
                            for (int i = 0; i < pilaUnida.length; i++) { //recorre cada eleento de la pila unido para imprimirlo
                                System.out.println(pilaUnida[i]);
                            }
                        } else {
                            System.out.println("La pila unida está vacía o no se ha generado.");
                        }
                        break;
                    case "d":
                        System.out.println("Salio. Gracias");
                        break;
                    default:
                        System.out.println("Error ingresa opcion valida");
                }

            } catch (InputMismatchException e) {
                System.out.println("Ingresa una opcion correcta");
                teclado.next();
                opcion2 = null;
            }
        } while (!"d".equals(opcion2));
    }

}
